from django.shortcuts import render, redirect

def index(request):
	return render(request,"index.html")

def process(request):
	if request.method =="GET":
		return redirect("/")
	if 'count' not in request.session:
		request.session["count"] = 0
	request.session["count"] += 1
	print request.POST
	request.session["name"] = request.POST["name"]
	request.session["favLang"] = request.POST["favLang"]
	request.session["comment"] = request.POST["comment"]
	return redirect("/result")

def result(request):
	return render(request, "result.html")
# Create your views here.